#include "_208643270_a.h"

REGISTER_ALGORITHM(_208643270_a)

// this alg is a direct implementation of the SuperAlgorithm
