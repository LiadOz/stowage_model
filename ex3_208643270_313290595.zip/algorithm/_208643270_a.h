#pragma once 
#include "SuperAdvancedAlgorithm.h"


// an improvement of algorithm c it prioritizes far cargos
// and uses the move policy defined in alg d
// other algorithms will inherit this class and try to improve
// only the move policy
class _208643270_a : public SuperAdvancedAlgorithm {
public:
    _208643270_a (){};
    virtual ~_208643270_a(){};
};
