#include <iostream>
#include "../interfaces/AbstractAlgorithm.h"

#include "_208643270_a.h"
int main() {
    std::cout << "hello" << std::endl;
    AbstractAlgorithm* a = new _208643270_a();
    delete a;
    std::cout << "goodbye" << std::endl;
    return 0;
}
